package com.company;
import java.awt.event.*;//to implement action Listener
import javax.swing.*;
class OnlineTest extends JFrame implements ActionListener
{
        JLabel L;//JLabel is a class of java swing.
        JRadioButton rb[] = new JRadioButton[5];//JRadioButton is a class of java swing.
        JButton b1,b2;//JButton is a class of java swing.
        ButtonGroup bg;//ButtonGroup is used to create set of buttons and in this it is used to select anyone radio button.
        int count = 0,current= 0,x = 1, y = 1, now = 0;//declaring this variable to point the current question.
        int m[] = new int[10];
        OnlineTest(String s)
        {
            super(s);//refers to superclass(parent).It is also used to call superclass methods and to access the superclass constructor.
            L = new JLabel();
            add(L);
            bg = new ButtonGroup();
            for(int i = 0;i<5;i++)//loop used to add the radio button in ButtonGroup bg.
            {
                rb[i] = new JRadioButton();
                add(rb[i]);
                bg.add(rb[i]);
            }
            b1 = new JButton("Next");
            b2 = new JButton("Later");
            b1.addActionListener(this);//using this keyword means "this object I'm working in right now" or can say "this" is a reference to the current object.
            b2.addActionListener(this);
            add(b1);add(b2);
            set();//we need to create method for this set().
            L.setBounds(30,40,850,20);//setting the bound of JLabel.
            rb[0].setBounds(50,80,100,20);//setting the Radiobutton.
            rb[1].setBounds(50,110,100,20);//y of jb[1] should be more than y of jb[0] so it will be exactly down of the 1st RadioButton.
            rb[2].setBounds(50,140,100,20);
            rb[3].setBounds(50,170,100,20);
            b1.setBounds(180,240,60,30);
            b2.setBounds(240,240,210,30);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//The setDefaultCloseOperation() method is used to specify one of several options for the close button.
            setLayout(null);//By default, the JPanel has a FlowLayout manager. The layout manager is used to place widgets onto the containers. If we call setLayout(null) we can position our components absolutely.
            setLocation(250,100);
            setVisible(true);
            setSize(600,350);
        }
    @Override
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==b1)
        {
            if(check())
                count=count+1;
            current++;
            set();
            if(current==9)
            {
                b1.setEnabled(false);
                b2.setText("Result");
            }
        }
        if(e.getActionCommand().equals("Later"))
        {
            JButton bk=new JButton("Later"+x);
            bk.setBounds(480,20+30*x,100,30);
            add(bk);
            bk.addActionListener(this);
            m[x]=current;
            x++;
            current++;
            set();
            if(current==9)
                b2.setText("Result");
            setVisible(false);
            setVisible(true);
        }
        for(int i=0,y=1;i<x;i++,y++)
        {
            if(e.getActionCommand().equals("Later"+y))
            {
                if(check())
                    count=count+1;
                now=current;
                current=m[y];
                set();
                ((JButton)e.getSource()).setEnabled(false);
                current=now;
            }
        }

        if(e.getActionCommand().equals("Result"))
        {
            if(check())
                count=count+1;
            current++;
            //System.out.println("correct ans="+count);
            JOptionPane.showMessageDialog(this,"The correct answer is "+count);
            System.exit(0);
        }
    }
    void set()
    {
        rb[4].setSelected(true);
        if(current==0)
        {
            L.setText("Que1: Which one among these is not a primitive datatype?");
            rb[0].setText("int");rb[1].setText("Float");rb[2].setText("boolean");rb[3].setText("char");
        }
        if(current==1)
        {
            L.setText("Que2: Which class is available to all the class automatically?");
            rb[0].setText("Swing");rb[1].setText("Applet");rb[2].setText("Object");rb[3].setText("ActionEvent");
        }
        if(current==2)
        {
            L.setText("Que3: Which package is directly available to our class without importing it?");
            rb[0].setText("swing");rb[1].setText("applet");rb[2].setText("net");rb[3].setText("lang");
        }
        if(current==3)
        {
            L.setText("Que4: String class is defined in which package?");
            rb[0].setText("lang");rb[1].setText("Swing");rb[2].setText("Applet");rb[3].setText("awt");
        }
        if(current==4)
        {
            L.setText("Que5: Which institute is best for java coaching?");
            rb[0].setText("Utek");rb[1].setText("Aptech");rb[2].setText("SSS IT");rb[3].setText("jtek");
        }
        if(current==5)
        {
            L.setText("Que6: Which one among these is not a keyword?");
            rb[0].setText("class");rb[1].setText("int");rb[2].setText("get");rb[3].setText("if");
        }
        if(current==6)
        {
            L.setText("Que7: Which one among these is not a class? ");
            rb[0].setText("Swing");rb[1].setText("Actionperformed");rb[2].setText("ActionEvent");
            rb[3].setText("Button");
        }
        if(current==7)
        {
            L.setText("Que8: which one among these is not a function of Object class?");
            rb[0].setText("toString");rb[1].setText("finalize");rb[2].setText("equals");
            rb[3].setText("getDocumentBase");
        }
        if(current==8)
        {
            L.setText("Que9: which function is not present in Applet class?");
            rb[0].setText("init");rb[1].setText("main");rb[2].setText("start");rb[3].setText("destroy");
        }
        if(current==9)
        {
            L.setText("Que10: Which one among these is not a valid component?");
            rb[0].setText("JButton");rb[1].setText("JList");rb[2].setText("JButtonGroup");
            rb[3].setText("JTextArea");
        }
        L.setBounds(30,40,450,20);
        for(int i=0,j=0;i<=90;i+=30,j++)
            rb[j].setBounds(50,80+i,200,20);
    }
    boolean check()
    {
        if(current==0)
            return(rb[1].isSelected());
        if(current==1)
            return(rb[2].isSelected());
        if(current==2)
            return(rb[3].isSelected());
        if(current==3)
            return(rb[0].isSelected());
        if(current==4)
            return(rb[2].isSelected());
        if(current==5)
            return(rb[2].isSelected());
        if(current==6)
            return(rb[1].isSelected());
        if(current==7)
            return(rb[3].isSelected());
        if(current==8)
            return(rb[1].isSelected());
        if(current==9)
            return(rb[2].isSelected());
        return false;
    }
    public static void main(String s[])
    {
        new OnlineTest("Online Test Of Java");
    }
}